/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "lcd.h"
#include "stdio.h"
#include "string.h"
/* Private includes ----------------------------------------------------------*/

/* Private typedef -----------------------------------------------------------*/

/* Private define ------------------------------------------------------------*/

/* Private macro -------------------------------------------------------------*/

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc2;
uint8_t KEYB1_FLAG = 0;
uint8_t KEYB2_FLAG = 0;
uint8_t KEYB3_FLAG = 0;
uint8_t KEYB4_FLAG = 0;
uint16_t Upper = 1;
uint16_t Lower = 2;
uint16_t adc;
double V;
double Max_Volt = 2.4;
double Min_Volt = 1.2;
char ADC_TEXT[50];
char LCD_TEXT[50];
char LD_TEXT[30];
/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC2_Init(void);
void LED_Init(void);//zhtdbb
void Key_Volt_Change(double *Volt);
void Key_LD_Change(uint16_t *LD);
void LD_Upper_Warning(void);
void LD_Lower_Warning(void);
void LD_Normal(void);
double Get_ADC(void);
uint8_t Key_Scan(GPIO_TypeDef *GPIOx,uint16_t GPIO_PIN);
/* Private user code ---------------------------------------------------------*/


/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC2_Init();
	
	LCD_Init();
	LCD_Clear(White);
	LED_Init();
  /* Infinite loop */
  while (1)
  {
		//exchange interface
		if(KEYB1_FLAG >1)
			KEYB1_FLAG = 0;
		//Data display interface
		if(KEYB1_FLAG == 0)
		{
			LCD_SetBackColor(Blue);
			LCD_SetTextColor(White);
			LCD_DisplayStringLine(Line0,(uint8_t*)"                    ");
			LCD_DisplayStringLine(Line1,(uint8_t*)"       Main         ");
			LCD_DisplayStringLine(Line2,(uint8_t*)"                    ");
			LCD_DisplayStringLine(Line3,(uint8_t*)"                    ");
			LCD_DisplayStringLine(Line4,(uint8_t*)"  Volt:             ");
			LCD_DisplayStringLine(Line5,(uint8_t*)"                    ");
			LCD_DisplayStringLine(Line6,(uint8_t*)"                    ");
			LCD_DisplayStringLine(Line7,(uint8_t*)"                    ");
			LCD_DisplayStringLine(Line8,(uint8_t*)"                    ");
			LCD_DisplayStringLine(Line9,(uint8_t*)"                    ");
			
			V = Get_ADC();
			sprintf(ADC_TEXT,"  Volt:%.2fV        ",V);
			LCD_DisplayStringLine(Line4,(uint8_t*)ADC_TEXT);
			
			if( V >= Max_Volt)
			{
				LCD_DisplayStringLine(Line6,(uint8_t*)"  Status:Upper      ");
				LD_Upper_Warning();
			}
			if( V < Max_Volt && V > Min_Volt)
			{
				LCD_DisplayStringLine(Line6,(uint8_t*)"  Status:Normal     ");
				LD_Normal();
			}
			if( V <= Min_Volt)
			{
				LCD_DisplayStringLine(Line6,(uint8_t*)"  Status:Lower      ");
				LD_Lower_Warning();
			}
			if(Key_Scan(B1_Setting_GPIO_Port,B1_Setting_Pin) ==2)
			{
				KEYB1_FLAG += 1;
			}
		}
		//Param setting interface
		else
		{
			if(Key_Scan(B2_Selection_GPIO_Port,B2_Selection_Pin) == 2)
				KEYB2_FLAG += 1;
			if(KEYB2_FLAG > 4)
				KEYB2_FLAG = 0;
			LCD_SetBackColor(White);
			LCD_SetTextColor(Blue);
			LCD_DisplayStringLine(Line0,(uint8_t*)"                    ");
			LCD_DisplayStringLine(Line1,(uint8_t*)"      Setting       ");
			LCD_DisplayStringLine(Line2,(uint8_t*)"                    ");
			LCD_DisplayStringLine(Line5,(uint8_t*)"                    ");
			LCD_DisplayStringLine(Line8,(uint8_t*)"                    ");
			LCD_DisplayStringLine(Line9,(uint8_t*)"                    ");
			sprintf(LCD_TEXT,"  Max Volt:%.2fV       ",Max_Volt);
			if(KEYB2_FLAG == 1)
			{
				LCD_SetBackColor(Green);
				LCD_DisplayStringLine(Line3,(uint8_t*)LCD_TEXT);
				LCD_SetBackColor(White);
				
				Key_Volt_Change(&Max_Volt);
			}
			else
				LCD_DisplayStringLine(Line3,(uint8_t*)LCD_TEXT);
			
			sprintf(LCD_TEXT,"  Min Volt:%.2fV       ",Min_Volt);
			if(KEYB2_FLAG == 2)
			{
				LCD_SetBackColor(Green);
				LCD_DisplayStringLine(Line4,(uint8_t*)LCD_TEXT);
				LCD_SetBackColor(White);
				
				Key_Volt_Change(&Min_Volt);
			}
			else
				LCD_DisplayStringLine(Line4,(uint8_t*)LCD_TEXT);
			
			sprintf(LD_TEXT,"  Upper:LD%d            ",Upper);
			if(KEYB2_FLAG == 3)
			{
				LCD_SetBackColor(Green);
				LCD_DisplayStringLine(Line6,(uint8_t*)LD_TEXT);
				LCD_SetBackColor(White);
				
				Key_LD_Change(&Upper);
			}
			else
				LCD_DisplayStringLine(Line6,(uint8_t*)LD_TEXT);
			
			sprintf(LD_TEXT,"  Lower:LD%d            ",Lower);
			if(KEYB2_FLAG == 4)
			{
				LCD_SetBackColor(Green);
				LCD_DisplayStringLine(Line7,(uint8_t*)LD_TEXT);
				LCD_SetBackColor(White);
				
				Key_LD_Change(&Lower);
			}
			else
				LCD_DisplayStringLine(Line7,(uint8_t*)LD_TEXT);
			
			if(Key_Scan(B1_Setting_GPIO_Port,B1_Setting_Pin) ==2)
			{
				KEYB1_FLAG += 1;
			}
			
			if(Upper == Lower)
			{
				LCD_SetTextColor(Red);
				LCD_DisplayStringLine(Line5,(uint8_t*)"  LD Conflicted!    ");
			}
			else
				LCD_DisplayStringLine(Line5,(uint8_t*)"                    ");
		}
  }
}

/**
  * @brief  LD normal mode
	* @param	none
  * @retval none
  */
void LD_Normal()
{
	HAL_GPIO_WritePin(LD_Control_GPIO_Port,LD_Control_Pin,GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,GPIO_PIN_SET);
	HAL_GPIO_WritePin(LD_Control_GPIO_Port,LD_Control_Pin,GPIO_PIN_RESET);
}
/**
  * @brief  Upper LD Warning
	* @param	none
  * @retval none
  */
void LD_Upper_Warning()
{
	GPIOC -> ODR = ~(0x0001 << (Upper + 7));
	HAL_GPIO_WritePin(LD_Control_GPIO_Port,LD_Control_Pin,GPIO_PIN_SET);
	HAL_GPIO_WritePin(LD_Control_GPIO_Port,LD_Control_Pin,GPIO_PIN_RESET);
	
	HAL_Delay(200);
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,GPIO_PIN_SET);
	HAL_GPIO_WritePin(LD_Control_GPIO_Port,LD_Control_Pin,GPIO_PIN_SET);
	HAL_GPIO_WritePin(LD_Control_GPIO_Port,LD_Control_Pin,GPIO_PIN_RESET);
}

/**
  * @brief  Lower LD Warning
	* @param	none
  * @retval none
  */
void LD_Lower_Warning()
{
	GPIOC -> ODR = ~(0x0001 << (Lower + 7));
	HAL_GPIO_WritePin(LD_Control_GPIO_Port,LD_Control_Pin,GPIO_PIN_SET);
	HAL_GPIO_WritePin(LD_Control_GPIO_Port,LD_Control_Pin,GPIO_PIN_RESET);
	
	HAL_Delay(200);
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,GPIO_PIN_SET);
	HAL_GPIO_WritePin(LD_Control_GPIO_Port,LD_Control_Pin,GPIO_PIN_SET);
	HAL_GPIO_WritePin(LD_Control_GPIO_Port,LD_Control_Pin,GPIO_PIN_RESET);
}

/**
  * @brief  Keys change LD
  * @retval none
  */
void Key_LD_Change(uint16_t *LD)
{
	if (Key_Scan(B3_Plus_GPIO_Port,B3_Plus_Pin) == 2)
	{
		*LD += 1;
		if(*LD >= 8)
			*LD = 8;
	}
	
	if(Key_Scan(B4_Minus_GPIO_Port,B4_Minus_Pin) == 2)
	{
		*LD -= 1;
		if(*LD <= 1)
			*LD = 1;
	}
}

/**
  * @brief  Keys change volt
  * @retval none
  */
void Key_Volt_Change(double *Volt)
{
	if (Key_Scan(B3_Plus_GPIO_Port,B3_Plus_Pin) == 2)
	{
		*Volt += 0.3;
		if(*Volt >= 3.3)
			*Volt = 3.3;
	}
	
	if(Key_Scan(B4_Minus_GPIO_Port,B4_Minus_Pin) == 2)
	{
		*Volt -= 0.3;
		if(*Volt <= 0)
			*Volt = 0;
	}
}

/**
  * @brief  KEY Scan
	* @param	Pressing the key is 2
						The key not pressed is 1
  * @retval unsigned int 8
  */
uint8_t Key_Scan(GPIO_TypeDef *GPIOx,uint16_t GPIO_PIN)
{
	if(HAL_GPIO_ReadPin(GPIOx,GPIO_PIN) == RESET)
	{
		while(HAL_GPIO_ReadPin(GPIOx,GPIO_PIN) == RESET)
			;
		return 2;
	}
	else
		return 1;
}

/**
  * @brief  Get ADC Value.
  * @retval double
  */
double Get_ADC()
{
	HAL_ADC_Start(&hadc2);						//����ADC2
	adc = HAL_ADC_GetValue(&hadc2);		//�������adc�����ڻ�ȡADC2��ֵ
	
	return (adc*3.3/4096);						//��������ֵΪadc*3.3/4096��3.3VΪ����ѹֵ��4096Ϊ12λ��LSB
}

/**
  * @brief  LED Initialize.
  * @retval none
  */
void LED_Init()
{
	HAL_GPIO_WritePin(LD_Control_GPIO_Port,LD_Control_Pin,GPIO_PIN_SET);				//PD2 = 1 Unlocked
	
	//Turn off all led lights
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15,GPIO_PIN_SET);
	HAL_GPIO_WritePin(LD_Control_GPIO_Port,LD_Control_Pin,GPIO_PIN_RESET);			//PD2 = 0 Locked
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC2_Init(void)
{
  ADC_ChannelConfTypeDef sConfig = {0};
  /** Common config
  */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.GainCompensation = 0;
  hadc2.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc2.Init.LowPowerAutoWait = DISABLE;
  hadc2.Init.ContinuousConvMode = DISABLE;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.DMAContinuousRequests = DISABLE;
  hadc2.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc2.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_15;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_2CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB2 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PC8 PC9 PC10 PC11 PC12 PC13 PC14 PC15 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PD2 */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
}
/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

